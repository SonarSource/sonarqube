var port = exports.port = 1337
exports.registry = "http://localhost:" + port
